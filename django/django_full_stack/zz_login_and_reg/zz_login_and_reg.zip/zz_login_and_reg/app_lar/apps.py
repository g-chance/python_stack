from django.apps import AppConfig


class AppLarConfig(AppConfig):
    name = 'app_lar'
