from django.apps import AppConfig


class AppCoursesConfig(AppConfig):
    name = 'app_courses'
