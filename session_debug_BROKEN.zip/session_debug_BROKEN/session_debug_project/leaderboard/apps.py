from django.apps import AppConfig


class LeaderboardConfig(AppConfig):
    name = 'leaderboard'
